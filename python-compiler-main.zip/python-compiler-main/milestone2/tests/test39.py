
# class A:
#     x: int = 5

# a: A = A()
# b: A = A()
# # b: str = "str"
# # b = a
# a+b
# if a == b:
#     print("equal")
# else:
#     print("not equal")

# x: int = 1
# y: int = 2
# x&=y
a:int=3
if "Str"!="str":
    # print("geet")
    a+=1
if ("Str"=="str")+1:
    # print("geet")
    a+=1
if "Str">="str":
    # print("geet")
    a+=1

# +, -, *, /, //, %, ** ==, !=, >, <, >=, <=
# and, or, not
# &, |, ˆ, ˜, <<, >>
# =, +=, -=, *=, /=, %=, **=, &=, |=, ˆ=, <<=, >>=
# a+=b

if (1 < 3.14)+8:
    print("yo")

# if not "":
#    print("if")
# else:
#     print("else")
