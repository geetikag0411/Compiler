s:str="geet"
s2:str="geet2"
if s==s2:
    print("Strings are equal")
else:   
    print("Strings are not equal")