class A:
    def __init__(self):
        self.m : int = 9

class B:
        # m_obj
    def __init__(self):
        m_obj: A = A()
        ((self).n) : int
        # self

x: int = 10
