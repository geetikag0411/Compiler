i:int
j:int

for i-j in range (1,2):
    print(i+j)

for i*j in range (1,2):
    print(i+j)# 5+6=4

# a:class=A()
# b:class=a
# a:list[int]=[1,2,3]

class A:
    def __init__(self):
        self.a:int= 5
        self.b:int= 6

b:A=A()

c:A=A()


(c:=b)
# 1+2 = 3
i: int
j: int
i+j = 5
for i+j in range (1,2):
    print(i+j)


