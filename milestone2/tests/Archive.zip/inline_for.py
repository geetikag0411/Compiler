a: list[int] = [i for i in range(10)]
x:int = [1 if 5>2 else 3]
