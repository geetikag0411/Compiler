x: list[str]=[2,3.4,"enfek",True]
print(x,x[2]*x[0],x[2],x[2]*x[3])

if "str" and 0:
    print("True")