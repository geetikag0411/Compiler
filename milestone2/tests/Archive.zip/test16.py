for i in range(True):
    print(i)