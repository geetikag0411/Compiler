a:int=6

def geet(a:int,b:bool)->int:
    return a

# class ant:
#     x: int
#     y: list[float]
    
#     def add(x: int):
#         return x+1
geet(1,True)



# x: list[int] = [1,2,3,4,5]

