(print)()
print(3.14)
print("asdflkjsadflk")
print(3+5.4/1)
x: list[float]
# print(x)
