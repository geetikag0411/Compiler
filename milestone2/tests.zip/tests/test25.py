class A:
    def good(self: A):
        print("A.good")
a : A = A()
a.good()
