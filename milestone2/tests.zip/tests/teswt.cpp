#include <iostream>
int main()
{
    int x;
    std::cout<<x;
}