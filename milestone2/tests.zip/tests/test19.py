# geet:bool=45.5
# c:bool=1
# d:int=c
# # print(c)
# # print(6.7//45.6%c)
# a:float=3<<4>>2|c +d
# print(6.7//45.6%d)
# b:int=(1|3) and 1 - 2>>5
# c:bool=(1|3) and 1.5
# e:bool=(1|3) and "rwgttw"
r:int=1+2*3-4/5-6+7*8
a:int=r
# print(b)
# a:int=5
b:int=(a:=5)

