a : int = 9
b : int = 20
def f():
    global a, b
    a =9
    b: float = 9.78
    print(a)
f()
    
