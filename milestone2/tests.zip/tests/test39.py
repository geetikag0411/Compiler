
class A:
    x: int = 5

a: A = A()
b: A = A()
# b: str = "str"
# b = a
a+b
if a == b:
    print("equal")
else:
    print("not equal")

x: int = 1
y: int = 2
x&=y


# +, -, *, /, //, %, ** ==, !=, >, <, >=, <=
# and, or, not
# &, |, ˆ, ˜, <<, >>
# =, +=, -=, *=, /=, %=, **=, &=, |=, ˆ=, <<=, >>=
# a+=b

if 1 < 3.14+True:
    print("yo")

# if not "":
#    print("if")
# else:
#     print("else")
