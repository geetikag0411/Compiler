#vneoei
x: int = 5
