i:int=8
j:int
for i in range(5,8):
    for j in range(1):
        print(i+j)
    else:
            print("yo")
# else:
#     print("yo")
    #
break
