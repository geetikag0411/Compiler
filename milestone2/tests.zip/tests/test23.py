class A:
    i :int = 0
    for i in range (5):
        print(i)
