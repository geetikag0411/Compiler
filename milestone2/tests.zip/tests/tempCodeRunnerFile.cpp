f(true)
    // x = 1;