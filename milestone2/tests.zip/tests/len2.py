x: list[int] = [1,2,3,4,5]
sz: int = len(x)

def func(x: int, y: bool) -> None:
    return

func(1,True)
