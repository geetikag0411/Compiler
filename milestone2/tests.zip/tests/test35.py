if 1<3:
    # if 4>5:
        print("4 is greater than 5")
#     elif 4<5:
#         print("4 is less than 5")
#     else:
#         print("4 is not greater than 5")
# elif 1==3:
#     print("1 is equal to 3")
# elif 1!=3:
#     print("1 is equal to 3")
# else :
#     print("1 is not less than 3")


# i: int

# if 1<3:
#     #  print("1 is less than 3")
#     i = 1
# elif 1==3:
#     # print("1 is equal to 3")
#     i = 2
# elif 1!=3:
#     # print("1 is equal to 3")
#     i = 3
# else :
#     # print("1 is not less than 3")
#     i = 4
    



# i: int
