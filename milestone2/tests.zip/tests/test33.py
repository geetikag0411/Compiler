class A:
    x: int
    y: int

# class B:
#     z: int
#     a: A
#     y:bool

# obj: B = B()
# obj.a.y = 5
# obj.y = True

o: list[int] = [1,2,3,4,5,]

# o[2] = 6
# o[1]+=5
